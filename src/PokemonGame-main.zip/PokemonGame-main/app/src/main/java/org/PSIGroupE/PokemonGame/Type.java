package org.PSIGroupE.PokemonGame;

public enum Type { DARK, DRAGON, FIRE, GRASS, GROUND, ICE, NORMAL, ROCK, STEEL, WATER}