package com.example.pokemongame;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

//import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.bumptech.glide.Glide;
//import java.io.File;
import org.PSIGroupE.PokemonGame.*;

public class MainActivity extends AppCompatActivity {
    private Button attack1;
    private Button attack2;
    private Button attack3;
    private Button attack4;
    private Button switch1;
    private Button switch2;
    private Button switch3;
    private Button switch4;
    private PokemonGame pokemonGame;
    private ImageView gifImageView;
    private ImageView ImageView;
    private ProgressBar progressBar;
    private ProgressBar progressBar2;
    private TextView textView;
    private TextView textView2;
    private int hp1,hp2,hp3,hp4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        progressBar = findViewById(R.id.progressBar);
        progressBar.getProgressDrawable().setColorFilter(Color.GREEN, android.graphics.PorterDuff.Mode.SRC_IN);
        //progressBar.getIndeterminateDrawable().setColorFilter(Color.GRAY, android.graphics.PorterDuff.Mode.SRC_IN);  // Color para el fondo
        progressBar2 = findViewById(R.id.progressBar2);
        progressBar2.getProgressDrawable().setColorFilter(Color.GREEN, android.graphics.PorterDuff.Mode.SRC_IN);
        //progressBar2.getIndeterminateDrawable().setColorFilter(Color.GRAY, android.graphics.PorterDuff.Mode.SRC_IN);  // Color para el fondo


        gifImageView = findViewById(R.id.gifImageView);
        ImageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.text1);
        textView2 = findViewById(R.id.text2);
        pokemonGame = new PokemonGame();
        pokemonGame.start();
        maxHP();
        progressBar.setMax(pokemonGame.getPlayer1().getActivePokemon().getHp());
        progressBar2.setMax(pokemonGame.getPlayer2().getActivePokemon().getHp());
        attack1 = findViewById(R.id.attack1);
        attack2 = findViewById(R.id.attack2);
        attack3 = findViewById(R.id.attack3);
        attack4 = findViewById(R.id.attack4);
        updateButtons();

        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        switch3 = findViewById(R.id.switch3);
        switch4 = findViewById(R.id.switch4);
        switch1.setText(pokemonGame.getPlayer1().getTeam()[0].getName());
        switch2.setText(pokemonGame.getPlayer1().getTeam()[1].getName());
        switch3.setText(pokemonGame.getPlayer1().getTeam()[2].getName());
        switch4.setText(pokemonGame.getPlayer1().getTeam()[3].getName());

        String imagePath2 = "https://play.pokemonshowdown.com/sprites/ani/" + pokemonGame.getPlayer2().getActivePokemon().getName().toLowerCase() + ".gif";
        Glide.with(this)
                .asGif()  // Indica que es un GIF
                .load(imagePath2)  // Pasa el archivo de la ruta
                .into(ImageView);


        attack1.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el texto
               pokemonGame.playMoves(1,pokemonGame.selectRandomMove());
               progressBar.setProgress(pokemonGame.getPlayer1().getActivePokemon().getHp());
            }
        });
        attack2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el text
                pokemonGame.playMoves(2,pokemonGame.selectRandomMove());
                progressBar.setProgress(pokemonGame.getPlayer1().getActivePokemon().getHp());
                progressBar2.setProgress(pokemonGame.getPlayer2().getActivePokemon().getHp());
            }
        });
        attack3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pokemonGame.playMoves(3,pokemonGame.selectRandomMove());
                progressBar.setProgress(pokemonGame.getPlayer1().getActivePokemon().getHp());
                progressBar2.setProgress(pokemonGame.getPlayer2().getActivePokemon().getHp());

            }
                // Llama a la función externa para cambiar el texto
        });
        attack4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el texto
                pokemonGame.playMoves(4,pokemonGame.selectRandomMove());
                progressBar.setProgress(pokemonGame.getPlayer1().getActivePokemon().getHp());
                progressBar2.setProgress(pokemonGame.getPlayer2().getActivePokemon().getHp());
            }
        });


        switch1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el texto
                pokemonGame.getPlayer1().setActivePokemon(0);
                updateButtons();
            }
        });
        switch2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el text
                pokemonGame.getPlayer1().setActivePokemon(1);
                updateButtons();

            }
        });
        switch3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pokemonGame.getPlayer1().setActivePokemon(2);
                updateButtons();

            }
            // Llama a la función externa para cambiar el texto
        });
        switch4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función externa para cambiar el texto
                pokemonGame.getPlayer1().setActivePokemon(3);
                updateButtons();
            }
        });

    }
    public void updateButtons(){
        textView.setText(pokemonGame.getPlayer1().getActivePokemon().getName());
        textView2.setText(pokemonGame.getPlayer2().getActivePokemon().getName());
        attack1.setText(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[0].getName());
        attack1.setBackgroundColor(Color.parseColor(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[0].getType().getColor()));
        attack2.setText(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[1].getName());
        attack2.setBackgroundColor(Color.parseColor(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[1].getType().getColor()));
        attack3.setText(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[2].getName());
        attack3.setBackgroundColor(Color.parseColor(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[2].getType().getColor()));
        attack4.setText(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[3].getName());
        attack4.setBackgroundColor(Color.parseColor(pokemonGame.getPlayer1().getActivePokemon().getAttacks()[3].getType().getColor()));
        String newImagePath = "https://play.pokemonshowdown.com/sprites/ani-back/" + pokemonGame.getPlayer1().getActivePokemon().getName().toLowerCase() + ".gif";
        Glide.with(MainActivity.this)
                .load(newImagePath)
                .into(gifImageView);
        return;
    }
    private void maxHP(){
        hp1 = pokemonGame.getPlayer1().getTeam()[0].getHp();
        hp2 = pokemonGame.getPlayer1().getTeam()[1].getHp();
        hp3 = pokemonGame.getPlayer1().getTeam()[2].getHp();
        hp4 = pokemonGame.getPlayer1().getTeam()[3].getHp();
    }
}